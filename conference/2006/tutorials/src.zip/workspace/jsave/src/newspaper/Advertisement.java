
// Created on Thu Jul 20 15:33:57 PDT 2006
// "Copyright Stanford University 2002"

package newspaper;

import java.util.*;
import java.beans.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;


/** 
 */
public abstract class Advertisement extends Content {

	public Advertisement(KnowledgeBase kb, FrameID id ) {
		super(kb, id);
	}

	public Advertisement(KnowledgeBase kb, String name , Cls cls ) {
		super(kb, name, cls);
	}

	public void setPurchaser(Instance purchaser) {
		Instance oldValue =  getPurchaser();
		ModelUtilities.setOwnSlotValue(this, "purchaser", purchaser);
		pcs.firePropertyChange("purchaser", oldValue, purchaser);
	}
	public Instance getPurchaser() {
		return ((Instance) ModelUtilities.getOwnSlotValue(this, "purchaser"));
	}

	public void setSalesperson(Instance salesperson) {
		Instance oldValue =  getSalesperson();
		ModelUtilities.setOwnSlotValue(this, "salesperson", salesperson);
		pcs.firePropertyChange("salesperson", oldValue, salesperson);
	}
	public Instance getSalesperson() {
		return ((Instance) ModelUtilities.getOwnSlotValue(this, "salesperson"));
	}

	public void setName(String name) {
		String oldValue =  getName();
		ModelUtilities.setOwnSlotValue(this, "name", name);
		pcs.firePropertyChange("name", oldValue, name);
	}
	public String getName() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "name"));
	}
/* writing listener */

	private PropertyChangeSupport pcs = new PropertyChangeSupport(this); 

	public void addPropertyChangeListener(PropertyChangeListener pcl) {
		pcs.addPropertyChangeListener(pcl);
	}
	public void removePropertyChangeListener(PropertyChangeListener pcl) {
		pcs.removePropertyChangeListener(pcl); 
	} 
// __Code above is automatically generated. Do not change
}
