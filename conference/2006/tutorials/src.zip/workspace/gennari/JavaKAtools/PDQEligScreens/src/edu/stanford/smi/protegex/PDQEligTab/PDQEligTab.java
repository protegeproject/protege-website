
package edu.stanford.smi.protegex.PDQEligTab;

import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.widget.*;

import java.awt.*;

public class PDQEligTab extends AbstractTabWidget /*implements TabWidget*/ {
	// attributes
	private JComboBox itsGenderWidget;
	private JTextField itsAgeWidget;
	private JTextField itsNodesWidget;
	private JComboBox itsPreviousTreatmentWidget;
	private JComboBox itsSettingWidget;
	private JComboBox itsReceptorStatusWidget;
	private JComboBox itsTumorStageWidget;
	private JComboBox itsNodeStatusWidget;
	private JComboBox itsPhaseWidget;

	private JList itsProtocolsWidget;
	private JLabel itsProtocolsLabel;

	private Action itsEditInstancesAction =
	  new AbstractAction() {
			public void actionPerformed(ActionEvent event) {
			  //  get my instance
			  Instance myInstance = (Instance) itsProtocolsWidget.getSelectedValue();
				showInstance(myInstance);
			}
	   };

	private DocumentListener itsDocumentListener;
	private ActionListener itsComboBoxListener;

	// must have a no argument constructor
	 public PDQEligTab() {

	}

	// initializers
	public void initialize() {

		// Should probably GetknowledgeBase here... ??

		setLabel("BreastCancer Triage");

		itsDocumentListener = new DocumentListener() {
			public void changedUpdate(DocumentEvent event) {
				clearProtocols();
			}
			public void insertUpdate(DocumentEvent event) {
				clearProtocols();
			}
			public void removeUpdate(DocumentEvent event) {
				clearProtocols();
			}
		};
		itsComboBoxListener = new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				clearProtocols();
			}
		};
		createWidgets();
		clearProtocols();
		setSize(300,300);
	}

	public String getTitle() {
		return "Eligibility";
	}
	public String getHelpText() {
		return "Triage patients to possible cancer protocols";
	}

	// commands

	// implementation
	private void createWidgets() {
		JSplitPane splitPane = ComponentFactory.createLeftRightSplitPane();
		splitPane.setLeftComponent(createLeftPane());
		splitPane.setRightComponent(createRightPane());
		setLayout(new BorderLayout());
		add(splitPane);
	}

	private JComponent createLeftPane() {
		JPanel pane = ComponentFactory.createPanel();
		pane.setLayout(new BorderLayout());
		JComponent patientPane = createPatientDataPane();
		JComponent patientPaneWrapper = ComponentFactory.createPanel();
		patientPaneWrapper.setLayout(new BorderLayout());
		patientPaneWrapper.add(patientPane);
		
		patientPaneWrapper.setBorder(BorderFactory.createEtchedBorder());
		JComponent labeledPane = new LabeledComponent("Patient Data", patientPaneWrapper, true);
		pane.add(labeledPane, BorderLayout.CENTER);
		pane.add(createFindProtocolButtonPane(), BorderLayout.SOUTH);
		pane.setPreferredSize(new Dimension(400, 0));

		return pane;
	}

	private JComponent createPatientDataPane() {
		JPanel pane = ComponentFactory.createPanel();
		pane.setLayout(new GridLayout(6, 2, 10, 5));
		// Border border = BorderFactory.createEmptyBorder(10, 10, 10, 10);
		// pane.setBorder(border);

		// row 0
		pane.add(createGenderWidget());
		pane.add(createAgeWidget());

		// row 1
		pane.add(createSettingWidget());
		pane.add(createPreviousTreatmentWidget());

		// row 2
		pane.add(createReceptorStatusWidget());
		pane.add(createTumorStageWidget());

		// row 3
		pane.add(createNodeStatusWidget());
		pane.add(createNodesWidget());

		// row 4
		pane.add(new JLabel());
		pane.add(new JLabel());

		// row 5
		pane.add(new JLabel());
		pane.add(createPhaseWidget());

		return pane;
	}

	private JTextField createTextField() {
		JTextField field = ComponentFactory.createTextField();
		field.getDocument().addDocumentListener(itsDocumentListener);
		return field;
	}
	private JComboBox createComboBox() {
		JComboBox box = ComponentFactory.createComboBox();
		box.addActionListener(itsComboBoxListener);
		return box;
	}

	// Methods for each widget listed in the Patient pane:

   	private JComponent createGenderWidget() {
		itsGenderWidget = createComboBox();
		itsGenderWidget.addItem("female");
		itsGenderWidget.addItem("male");
		itsGenderWidget.addItem("ignore");
		return new LabeledComponent("Gender", itsGenderWidget, false);
	}

	private JComponent createAgeWidget() {
		itsAgeWidget = createTextField();
		itsAgeWidget.setHorizontalAlignment(JTextField.RIGHT);
		itsAgeWidget.setText("ignore");
		return new LabeledComponent("Age", itsAgeWidget, false);
	}
	private JComponent createNodesWidget() {
		itsNodesWidget = createTextField();
		itsNodesWidget.setHorizontalAlignment(JTextField.RIGHT);
		itsNodesWidget.setText("ignore");
		return new LabeledComponent("# of positive nodes", itsNodesWidget, false);
	}

	private JComponent createPreviousTreatmentWidget() {
		itsPreviousTreatmentWidget = createComboBox();
		itsPreviousTreatmentWidget.addItem("ignore");
		itsPreviousTreatmentWidget.addItem("None");
		itsPreviousTreatmentWidget.addItem("Mastectomy");
		itsPreviousTreatmentWidget.addItem("Lumpectomy");
		itsPreviousTreatmentWidget.addItem("Radiotherapy");
		itsPreviousTreatmentWidget.addItem("Chemotherapy");
		return new LabeledComponent("Previous Treatment", itsPreviousTreatmentWidget, false);
	}

	private JComponent createPhaseWidget() {
		itsPhaseWidget = createComboBox();
		itsPhaseWidget.addItem("All protocols");
		itsPhaseWidget.addItem("Phase 1 only");
		itsPhaseWidget.addItem("Phase 2 only");
		itsPhaseWidget.addItem("Phase 3 only");
		itsPhaseWidget.addItem("ignore");
		return new LabeledComponent("What phase protocols?", itsPhaseWidget, false);
	}

	private JComponent createReceptorStatusWidget() {
		itsReceptorStatusWidget = createComboBox();
		itsReceptorStatusWidget.addItem("ignore");
		itsReceptorStatusWidget.addItem("Positive");
		itsReceptorStatusWidget.addItem("Negative");
		itsReceptorStatusWidget.addItem("Unknown");
		return new LabeledComponent("Hormone receptor status", itsReceptorStatusWidget, false);
	}

	private JComponent createTumorStageWidget() {
		itsTumorStageWidget = createComboBox();
		itsTumorStageWidget.addItem("ignore");
		itsTumorStageWidget.addItem("T1");
		itsTumorStageWidget.addItem("T2");
		itsTumorStageWidget.addItem("T3");
		itsTumorStageWidget.addItem("T4");
		return new LabeledComponent("Primary tumor status", itsTumorStageWidget, false);
	}

	private JComponent createNodeStatusWidget() {
		itsNodeStatusWidget = createComboBox();
		itsNodeStatusWidget.addItem("ignore");
		itsNodeStatusWidget.addItem("N0");
		itsNodeStatusWidget.addItem("N1");
		itsNodeStatusWidget.addItem("N2");
		itsNodeStatusWidget.addItem("N3");

		itsNodeStatusWidget.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent event) {
				if (itsNodeStatusWidget.getSelectedItem().equals("N0")) {
				   itsNodesWidget.setEnabled(false);
				   itsNodesWidget.setText("ignore");
				   itsNodesWidget.setBackground(Color.lightGray);
				} else {
				   itsNodesWidget.setEnabled(true);
				   itsNodesWidget.setBackground(Color.white);
				}
			}
		});
		return new LabeledComponent("Lymph node status", itsNodeStatusWidget, false);
	}

	/*
	private JComponent createMetastaticWidget() {
		itsMetastaticWidget = createComboBox();
		itsMetastaticWidget.addItem("ignore");
		itsMetastaticWidget.addItem("Present");
		itsMetastaticWidget.addItem("Absent");
		return new LabeledComponent(itsMetastaticWidget, "Metastatic disease");
	}
	*/

	private JComponent createSettingWidget() {
		itsSettingWidget = createComboBox();
		itsSettingWidget.addItem("ignore");
		itsSettingWidget.addItem("Adjuvant");
		itsSettingWidget.addItem("Locally advanced");
		itsSettingWidget.addItem("Recurrent");
		itsSettingWidget.addItem("Metastatic");
		return new LabeledComponent("Treatment setting", itsSettingWidget, false);
	}

	// The query button:
	private JComponent createFindProtocolButtonPane() {
		Action action = new AbstractAction("Find protocols for patient") {
			public void actionPerformed(ActionEvent event) {
				findEligibleProtocols();
			}
		};
		JButton button = ComponentFactory.createButton(action);

		JPanel pane = ComponentFactory.createPanel();
		pane.setLayout(new FlowLayout());
		pane.add(button);
		return pane;
	}

	private JComponent createRightPane() {
		JComponent pane = createResultPane();
		return pane;
	}

	private JComponent createResultPane() {
		itsProtocolsLabel = ComponentFactory.createLabel();
		itsProtocolsLabel.setText("Potential protocols");
		JComponent list = createProtocolList();
		JScrollPane scrollProtocolList = ComponentFactory.createScrollPane(list);
		LabeledComponent pane = new LabeledComponent("", scrollProtocolList, true);
		pane.setHeaderComponent(itsProtocolsLabel);
		return pane;
	}

	private JComponent createProtocolList() {
		itsProtocolsWidget = ComponentFactory.createList(itsEditInstancesAction);
		ListCellRenderer renderer = new FrameRenderer();
		itsProtocolsWidget.setCellRenderer(renderer);
		return itsProtocolsWidget;
	}


	private void findEligibleProtocols() {
		Patient patient = new Patient();
		try {
			int age = Integer.parseInt(itsAgeWidget.getText());
			patient.setAge(age);
		} catch (NumberFormatException e) {
			// ignore ages which are not numbers
			patient.setAge(-1);
		}
		try {
			int nodes = Integer.parseInt(itsNodesWidget.getText());
			patient.setNodes(nodes);
		} catch (NumberFormatException e) {
			// ignore nodes which are not numbers
			patient.setNodes(-1);
		}
		patient.setPreviousTreatment((String)itsPreviousTreatmentWidget.getSelectedItem());
		patient.setTxSetting((String)itsSettingWidget.getSelectedItem());
		patient.setTumorStage((String)itsTumorStageWidget.getSelectedItem());
		patient.setReceptorStatus((String)itsReceptorStatusWidget.getSelectedItem());
		patient.setNodeStatus((String)itsNodeStatusWidget.getSelectedItem());
		patient.setPhase((String)itsPhaseWidget.getSelectedItem());
		patient.setGender((String)itsGenderWidget.getSelectedItem());
	// add code here to check that everything has a valid value.

		Collection instances = findEligibleProtocols(patient);
		itsProtocolsWidget.setListData(instances.toArray());
		itsProtocolsWidget.setBackground((Color)UIManager.getColor("List.background"));
		itsProtocolsWidget.setEnabled(true);
		itsProtocolsLabel.setText("Matched Breast Cancer Treatment Protocols (" + instances.size() + ")");
		itsProtocolsWidget.revalidate();
		itsProtocolsWidget.repaint();
	}

	private Collection findEligibleProtocols(Patient patient) {
		TreeMap eligibleProtocols = new TreeMap(new ProtocolComparator());

		KnowledgeBase kb = getKnowledgeBase();
		Slot protoSlot = kb.getSlot("ProtocolName");
		Slot nameSlot = kb.getSlot("name"); // May have to change this if the ontology changes...
		Cls cls = kb.getCls("SimpleScreens");
		Iterator i = cls.getInstances().iterator();
		while (i.hasNext()) {
			Instance screen = (Instance) i.next();
			//System.out.println("    Checking against " + screen.getSlotValue("name").getSingleItem());
			if (patient.isEligible(screen, kb)) {
				  String ScreenName = (String) screen.getOwnSlotValue(nameSlot);
				Instance protocol = (Instance) screen.getOwnSlotValue(protoSlot);
				if (protocol == null) {
					System.out.println("Screen " + ScreenName + " has no protocol");
				} else {
				 String uniqueKey = (String)protocol.getOwnSlotValue(nameSlot);
				 //System.out.println("protocol name " + uniqueKey);
				 Object testing = eligibleProtocols.get(uniqueKey);
				 if(null==testing) {
				  eligibleProtocols.put(uniqueKey, protocol);
				 }
				}
			}
		}
		//System.out.println("done.");
		return eligibleProtocols.values();
	}

	private void clearProtocols() {
		if (itsProtocolsWidget != null && itsProtocolsWidget.isEnabled()) {
			itsProtocolsWidget.setListData(new Object[0]);
			itsProtocolsWidget.setBackground((Color)UIManager.getColor("List.background"));
			itsProtocolsWidget.setEnabled(false);
			itsProtocolsWidget.revalidate();
			itsProtocolsWidget.repaint();
			itsProtocolsLabel.setText("Breast Cancer Treatment Protocols");
		}
	}
} // end of class PDQEligTab