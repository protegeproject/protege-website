
// Created on Tue Jul 18 15:37:55 PDT 2006
// "Copyright Stanford University 2002"

package newspaper;

import java.util.*;
import java.beans.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;


/** 
 */
public abstract class Employee extends Person {

	public Employee(KnowledgeBase kb, FrameID id ) {
		super(kb, id);
	}

	public Employee(KnowledgeBase kb, String name , Cls cls ) {
		super(kb, name, cls);
	}

	public void setDate_hired(String date_hired) {
		String oldValue =  getDate_hired();
		ModelUtilities.setOwnSlotValue(this, "date_hired", date_hired);
		pcs.firePropertyChange("date_hired", oldValue, date_hired);
	}
	public String getDate_hired() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "date_hired"));
	}

	public void setCurrent_job_title(String current_job_title) {
		String oldValue =  getCurrent_job_title();
		ModelUtilities.setOwnSlotValue(this, "current_job_title", current_job_title);
		pcs.firePropertyChange("current_job_title", oldValue, current_job_title);
	}
	public String getCurrent_job_title() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "current_job_title"));
	}

	public void setSalary(float salary) {
		Float oldValue =  new Float(getSalary());
		ModelUtilities.setOwnSlotValue(this, "salary", new Float(salary));
		pcs.firePropertyChange("salary", oldValue, new Float(salary));
	}
	public float getSalary() {
		return ((Float) ModelUtilities.getOwnSlotValue(this, "salary")).floatValue();
	}
/* writing listener */

	private PropertyChangeSupport pcs = new PropertyChangeSupport(this); 

	public void addPropertyChangeListener(PropertyChangeListener pcl) {
		pcs.addPropertyChangeListener(pcl);
	}
	public void removePropertyChangeListener(PropertyChangeListener pcl) {
		pcs.removePropertyChangeListener(pcl); 
	} 
// __Code above is automatically generated. Do not change
}
