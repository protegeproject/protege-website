package edu.stanford.smi.protege.model.framestore;

/**
 * 
 * @author Ray Fergerson <fergerson@smi.stanford.edu>
 */
class ModificationException extends RuntimeException {
    ModificationException(String s) {
        super(s);
    }
}
