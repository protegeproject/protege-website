
// Created on Thu Jul 20 15:33:57 PDT 2006
// "Copyright Stanford University 2002"

package newspaper;

import java.util.*;
import java.beans.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;


/** 
 *  Articles are included here as soon as they are written--they could go for a while without being published. For example, an article on gardening could be submitted on Monday and not be published until Thursday (when the gardening section is included in the paper). 
 */
public class Article extends Content {

	public Article(KnowledgeBase kb, FrameID id ) {
		super(kb, id);
	}

	public Article(KnowledgeBase kb, String name , Cls cls ) {
		super(kb, name, cls);
	}

	public void setReading_level(String reading_level) {
		String oldValue =  getReading_level();
		ModelUtilities.setOwnSlotValue(this, "reading_level", reading_level);
		pcs.firePropertyChange("reading_level", oldValue, reading_level);
	}
	public String getReading_level() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "reading_level"));
	}

	public void setArticle_type(String article_type) {
		String oldValue =  getArticle_type();
		ModelUtilities.setOwnSlotValue(this, "article_type", article_type);
		pcs.firePropertyChange("article_type", oldValue, article_type);
	}
	public String getArticle_type() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "article_type"));
	}

	public void setKeywords(String[] keywords) {
		String[] oldValue =  getKeywords();
		Collection keywordsCollection = Arrays.asList(keywords); 
		ModelUtilities.setOwnSlotValues(this, "keywords", keywordsCollection);
		pcs.firePropertyChange("keywords", oldValue, keywords);
	}
	public String[] getKeywords(){
		return (String[])  ModelUtilities.getOwnSlotValues(this, "keywords").toArray(new String[0]);
	}

	public void setHeadline(String headline) {
		String oldValue =  getHeadline();
		ModelUtilities.setOwnSlotValue(this, "headline", headline);
		pcs.firePropertyChange("headline", oldValue, headline);
	}
	public String getHeadline() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "headline"));
	}

	public void setText(String text) {
		String oldValue =  getText();
		ModelUtilities.setOwnSlotValue(this, "text", text);
		pcs.firePropertyChange("text", oldValue, text);
	}
	public String getText() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "text"));
	}

	public void setAuthor(Instance author) {
		Instance oldValue =  getAuthor();
		ModelUtilities.setOwnSlotValue(this, "author", author);
		pcs.firePropertyChange("author", oldValue, author);
	}
	public Instance getAuthor() {
		return ((Instance) ModelUtilities.getOwnSlotValue(this, "author"));
	}
/* writing listener */

	private PropertyChangeSupport pcs = new PropertyChangeSupport(this); 

	public void addPropertyChangeListener(PropertyChangeListener pcl) {
		pcs.addPropertyChangeListener(pcl);
	}
	public void removePropertyChangeListener(PropertyChangeListener pcl) {
		pcs.removePropertyChangeListener(pcl); 
	} 
// __Code above is automatically generated. Do not change
}
