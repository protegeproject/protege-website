package edu.stanford.smi.protege.model.framestore;

public interface IncludingKBSupport {
  void setIncludedFrames(IncludedFrameLookup iframes);
}
