package edu.stanford.smi.protege.model.framestore.cleandispatch;

import junit.framework.*;

public class _CleanDispatchPackage_Test {

    public static Test suite() {
        TestSuite suite = new TestSuite("model.framestore.cleandispatch");
        suite.addTestSuite(CleanDispatchFrameStore_Test.class);
        return suite;
    }
}
