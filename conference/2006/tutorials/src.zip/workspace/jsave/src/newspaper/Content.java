
// Created on Thu Jul 20 15:33:57 PDT 2006
// "Copyright Stanford University 2002"

package newspaper;

import java.util.*;
import java.beans.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;


/** 
 *  This is an abstract superclass of both advertisements and articles, containing the the information common to them both. 
 */
public abstract class Content extends DefaultSimpleInstance {

	public Content(KnowledgeBase kb, FrameID id ) {
		super(kb, id);
	}

	public Content(KnowledgeBase kb, String name , Cls cls ) {
		super(kb, name, cls);
	}

	public void setLayout(Instance layout) {
		Instance oldValue =  getLayout();
		ModelUtilities.setOwnSlotValue(this, "layout", layout);
		pcs.firePropertyChange("layout", oldValue, layout);
	}
	public Instance getLayout() {
		return ((Instance) ModelUtilities.getOwnSlotValue(this, "layout"));
	}

	public void setExpiration_date(String expiration_date) {
		String oldValue =  getExpiration_date();
		ModelUtilities.setOwnSlotValue(this, "expiration_date", expiration_date);
		pcs.firePropertyChange("expiration_date", oldValue, expiration_date);
	}
	public String getExpiration_date() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "expiration_date"));
	}

	public void setContaining_section(Instance containing_section) {
		Instance oldValue =  getContaining_section();
		ModelUtilities.setOwnSlotValue(this, "containing_section", containing_section);
		pcs.firePropertyChange("containing_section", oldValue, containing_section);
	}
	public Instance getContaining_section() {
		return ((Instance) ModelUtilities.getOwnSlotValue(this, "containing_section"));
	}

	public void setPage_number(int page_number) {
		Integer oldValue =  new Integer(getPage_number());
		ModelUtilities.setOwnSlotValue(this, "page_number", new Integer(page_number));
		pcs.firePropertyChange("page_number", oldValue, new Integer(page_number));
	}
	public int getPage_number() {
		return ((Integer) ModelUtilities.getOwnSlotValue(this, "page_number")).intValue();
	}

	public void setPublished_in(Instance published_in) {
		Instance oldValue =  getPublished_in();
		ModelUtilities.setOwnSlotValue(this, "published_in", published_in);
		pcs.firePropertyChange("published_in", oldValue, published_in);
	}
	public Instance getPublished_in() {
		return ((Instance) ModelUtilities.getOwnSlotValue(this, "published_in"));
	}

	public void setUrgent(boolean urgent) {
		Boolean oldValue =  new Boolean(isUrgent());
		ModelUtilities.setOwnSlotValue(this, "urgent", new Boolean(urgent));
		pcs.firePropertyChange("urgent", oldValue, new Boolean(urgent));
	}
	public boolean isUrgent() {
		if (ModelUtilities.getOwnSlotValue(this, "urgent") == null) return false;
		else 
		return ((Boolean) ModelUtilities.getOwnSlotValue(this, "urgent")).booleanValue();
	}
/* writing listener */

	private PropertyChangeSupport pcs = new PropertyChangeSupport(this); 

	public void addPropertyChangeListener(PropertyChangeListener pcl) {
		pcs.addPropertyChangeListener(pcl);
	}
	public void removePropertyChangeListener(PropertyChangeListener pcl) {
		pcs.removePropertyChangeListener(pcl); 
	} 
// __Code above is automatically generated. Do not change
}
