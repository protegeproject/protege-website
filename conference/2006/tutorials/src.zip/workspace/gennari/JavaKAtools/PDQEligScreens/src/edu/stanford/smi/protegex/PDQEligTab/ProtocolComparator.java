
package edu.stanford.smi.protegex.PDQEligTab;

import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.widget.*;

import java.awt.*;

/*******************************************************************/

class ProtocolComparator implements Comparator
{
  public int compare (Object A, Object B)
  {
   String aValue = (String)A;
   String bValue = (String)B;
   int rvalue;
   if (null==aValue) {
	  rvalue = (bValue == null) ? 0 : -1;
   } else {
	  rvalue = aValue.compareTo(bValue);
   }
   return rvalue;
  }  
}