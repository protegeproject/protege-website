
package edu.stanford.smi.protegex.PDQEligTab;

import java.awt.event.*;
import java.util.*;
import javax.swing.*;
import javax.swing.event.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.ui.*;
import edu.stanford.smi.protege.util.*;
import edu.stanford.smi.protege.widget.*;

import java.awt.*;

/*******************************************************************/

class Patient {
	private int itsAge;
	private String itsPreviousTreatment;
	private String itsSetting;
	private String itsTumorStage;
	private String itsReceptorStatus;
	private String itsNodeStatus;
	private String itsGender;
	private int itsNodes;
	private String itsPhase;

	public void setAge(int age) {
		itsAge = age;
	}
	public void setNodes(int nodes) {
		itsNodes = nodes;
	}
	public void setPreviousTreatment(String treatment) {
		itsPreviousTreatment = treatment;
	}
	public void setGender(String gender) {
		itsGender = gender;
	}
	public void setPhase(String phase) {
		itsPhase = phase;
	}
	public void setTxSetting(String setting) {
		itsSetting = setting;
	}
	public void setTumorStage(String tumor) {
		itsTumorStage = tumor;
	}
	public void setNodeStatus(String nodestatus) {
		itsNodeStatus = nodestatus;
	}
	public void setReceptorStatus(String receptor) {
		itsReceptorStatus = receptor;
	}

	public boolean isEligible(Instance screen, KnowledgeBase kb) {
		boolean isEligible;
		isEligible = checkAge(screen, kb);
		if (isEligible) { isEligible = checkPhase(screen, kb);
		}
		if (isEligible) { isEligible = checkPreviousTreatment(screen, kb);
		}
		if (isEligible) { isEligible = checkSetting(screen, kb);
		}
		if (isEligible) { isEligible = checkTumorStage(screen, kb);
		}
		if (isEligible) { isEligible = checkNodeStatus(screen, kb);
		}
		if (isEligible) { isEligible = checkReceptor(screen, kb);
		}
		if (isEligible) { isEligible = checkNodes(screen, kb);
		}
		if (isEligible) { isEligible = checkGender(screen, kb);
		}
		return isEligible;
	}

	// implementation of each screen:
	private boolean checkAge(Instance screen, KnowledgeBase kb) {
		boolean pass;
	  Slot ageSlot = kb.getSlot("Age");
		String KBallowedAge = (String) screen.getOwnSlotValue(ageSlot);
		if ((KBallowedAge == null) || (itsAge < 0)) {
			pass = true;
		} else if (KBallowedAge.equals(">18")) {
			pass = itsAge >= 18;
		} else if (KBallowedAge.equals("18-50")) {
			pass = 18 <= itsAge && itsAge <= 50;
		} else if (KBallowedAge.equals("18-65")) {
			pass = 18 <= itsAge && itsAge <= 65;
		} else if (KBallowedAge.equals(">50")) {
			pass = itsAge >= 50;
		} else if (KBallowedAge.equals(">65")) {
			pass = itsAge >= 65;
		} else if (KBallowedAge.equals("AnyAge")) {
			pass = true;
		} else if (KBallowedAge.equals("Unspecified")) {
			pass = true;
		} else {
			System.out.println("Unexpected age field value: " + KBallowedAge);
			pass = false;
		}
		return pass;
	}

	private boolean checkNodeStatus(Instance screen, KnowledgeBase kb) {
		boolean pass;
		Slot nStageSlot = kb.getSlot("N-stage");
		  String KBNodeStatus = (String) screen.getOwnSlotValue(nStageSlot);
		if ((KBNodeStatus == null) || itsNodeStatus.equals("ignore")) {
			pass = true;
		} else if (KBNodeStatus.equals("N0")) {
			pass = itsNodeStatus.equals("N0");
		} else if (KBNodeStatus.equals("N1")) {
			pass = itsNodeStatus.equals("N1");
		} else if (KBNodeStatus.equals("N0-1")) {
			pass = itsNodeStatus.equals("N1") || itsNodeStatus.equals("N0");
		} else if (KBNodeStatus.equals("N1-2")) {
			pass = itsNodeStatus.equals("N1") || itsNodeStatus.equals("N2");
		} else if (KBNodeStatus.equals("N1-3")) {
			pass = itsNodeStatus.equals("N1") || itsNodeStatus.equals("N2") ||
				 itsNodeStatus.equals("N3");
		} else if (KBNodeStatus.equals("N2")) {
			pass = itsNodeStatus.equals("N2");
		} else if (KBNodeStatus.equals("N3")) {
			pass = itsNodeStatus.equals("N3");
		} else if (KBNodeStatus.equals("Unspecified")) {
			pass = true;
		} else {
			System.out.println("Unexpected node status value: "
					+ KBNodeStatus);
			pass = false;
		}
		return pass;
	}

	private boolean checkPhase(Instance screen, KnowledgeBase kb) {
		boolean pass;
		Slot phaseSlot = kb.getSlot("Phase");
		  String KBPhase = (String)	screen.getOwnSlotValue(phaseSlot);
		if ((KBPhase == null) || itsPhase.equals("All protocols")) {
			pass = true;
		} else if (KBPhase.equals("Phase1")) {
			pass = itsPhase.equals("Phase 1 only");
		} else if (KBPhase.equals("Phase1/2")) {
			pass = itsPhase.equals("Phase 1 only") || itsPhase.equals("Phase 2 only");
		} else if (KBPhase.equals("Phase2")) {
			pass = itsPhase.equals("Phase 2 only");
		} else if (KBPhase.equals("Phase3")) {
			pass = itsPhase.equals("Phase 3 only");
		} else {
			System.out.println("Unexpected protocol phase value: "
					+ KBPhase);
			pass = false;
		}
		return pass;
	}

	private boolean checkGender(Instance screen, KnowledgeBase kb) {
		boolean pass;
		Slot genderSlot = kb.getSlot("Gender");
		  String KBgender = (String) screen.getOwnSlotValue(genderSlot);
		if ((KBgender == null) || itsGender.equals("ignore") ||
			KBgender.equals("Any") || KBgender.equals("Unspecified")) {
			pass = true;
		} else if (KBgender.equals("Female")) {
			pass = itsGender.equals("female");
		} else {
			System.out.println("Unexpected gender status value: " + KBgender);
			pass = false;
		}
		return pass;
	}

	/*
	private boolean checkMetastatic(Instance screen) {
		boolean pass;
		String KBmetastatic = (String)
				screen.getSlotValue("M-stage").getSingleItem();
		if ((KBmetastatic == null) || itsMetastatic.equals("ignore")) {
			pass = true;
		} else if (KBmetastatic.equals("M1")) {
			pass = itsMetastatic.equals("Present");
		} else if (KBmetastatic.equals("M0")) {
			pass = itsMetastatic.equals("Absent");
		} else if (KBmetastatic.equals("Unspecified")) {
			pass = true;
		} else {
			System.out.println("Unexpected metastatic status value: "
					+ KBmetastatic);
			pass = false;
		}
		return pass;
	}
	*/

	private boolean checkPreviousTreatment(Instance screen, KnowledgeBase kb) {
		boolean pass;
		Slot prevTreatSlot = kb.getSlot("PreviousTreatment");
		  String KBpreviousTreatment = (String) screen.getOwnSlotValue(prevTreatSlot);
		if ((KBpreviousTreatment == null) || itsPreviousTreatment.equals("ignore")) {
			pass = true;
		} else if (KBpreviousTreatment.equals("None")) {
			pass = itsPreviousTreatment.equals("None");
		} else if (KBpreviousTreatment.equals("Surgery")) {
			pass = itsPreviousTreatment.equals("Mastectomy") ||
				   itsPreviousTreatment.equals("Lumpectomy");
		} else if (KBpreviousTreatment.equals("Systemic")) {
			pass = itsPreviousTreatment.equals("RadioTherapy") ||
				   itsPreviousTreatment.equals("ChemoTherapy");
		} else if (KBpreviousTreatment.equals("RadiationTherapy")) {
			pass = itsPreviousTreatment.equals("RadioTherapy");
		} else if (KBpreviousTreatment.equals("Chemotherapy")) {
			pass = itsPreviousTreatment.equals("Chemotherapy");
		} else if (KBpreviousTreatment.equals("Unspecified")) {
			pass = true;
		} else {
			System.out.println("Unexpected previous treatment value: "
					+ KBpreviousTreatment);
			pass = false;
		}
	  return pass;
	}

	private boolean checkSetting(Instance screen, KnowledgeBase kb) {
		boolean pass;
		Slot treatSettingSlot = kb.getSlot("Treatment_setting");
		  String KBTxSetting = (String) screen.getOwnSlotValue(treatSettingSlot);
		if ((KBTxSetting == null) || itsSetting.equals("ignore")) {
			pass = true;
		} else if (KBTxSetting.equals("Metastatic")) {
			pass = itsSetting.equals("Metastatic");
		} else if (KBTxSetting.equals("Adjuvant")) {
			pass = itsSetting.equals("Adjuvant");
		} else if (KBTxSetting.equals("LocallyAdvanced")) {
			pass = itsSetting.equals("Locally advanced");
		} else if (KBTxSetting.equals("Recurrent")) {
			pass = itsSetting.equals("Recurrent");
		} else if (KBTxSetting.equals("Chemotherapy")) {
			pass = itsSetting.equals("Chemotherapy");
		} else if (KBTxSetting.equals("Unspecified") || KBTxSetting.equals("Any")) {
			pass = true;
		} else {
			System.out.println("Unexpected treatment treatment value: "
					+ KBTxSetting);
			pass = false;
		}
	  return pass;
	}

   private boolean checkTumorStage(Instance screen, KnowledgeBase kb) {
		boolean pass;
		Slot tStageSlot = kb.getSlot("T-stage");
		  String KBTumorStage = (String) screen.getOwnSlotValue(tStageSlot);
		if ((KBTumorStage == null) || itsTumorStage.equals("ignore")) {
			pass = true;
		} else if (KBTumorStage.equals("T0")) {
			pass = false; // The patient has at least T1...
		} else if (KBTumorStage.equals("T1")) {
			pass = itsTumorStage.equals("T1");
		} else if (KBTumorStage.equals("T1-2")) {
			pass = itsTumorStage.equals("T1") || itsTumorStage.equals("T2");
		} else if (KBTumorStage.equals("T1-3")) {
			pass = itsTumorStage.equals("T1") || itsTumorStage.equals("T2") ||
				 itsTumorStage.equals("T3");
		} else if (KBTumorStage.equals("T0-3")) {
			pass = itsTumorStage.equals("T1") || itsTumorStage.equals("T2") ||
				 itsTumorStage.equals("T3");
		} else if (KBTumorStage.equals("T1-4")) {
			pass = true;
		} else if (KBTumorStage.equals("T2")) {
			pass = itsTumorStage.equals("T2");
		} else if (KBTumorStage.equals("T3")) {
			pass = itsTumorStage.equals("T3");
		} else if (KBTumorStage.equals("T4")) {
			pass = itsTumorStage.equals("T4");
		} else {
			System.out.println("Unexpected tumor stage value: " + KBTumorStage);
			pass = false;
		}
		return pass;
   }   

   private boolean checkReceptor(Instance screen, KnowledgeBase kb) {
		boolean pass;
		Slot receptorSlot = kb.getSlot("EstProReceptor");
		  String KBReceptor = (String) screen.getOwnSlotValue(receptorSlot);
		if ((KBReceptor == null) || itsReceptorStatus.equals("ignore")) {
			pass = true;
		} else if (KBReceptor.equals("Any") || KBReceptor.equals("Unspecified")) {
			pass = true;
		} else if (KBReceptor.equals("Negative")) {
			pass = itsReceptorStatus.equals("Negative");
		} else if (KBReceptor.equals("Positive")) {
			pass = itsReceptorStatus.equals("Positive");
		} else {
			System.out.println("Unexpected hormone receptor status value: "
					+ KBReceptor);
			pass = false;
		}
		return pass;
   }   
	private boolean checkNodes(Instance screen, KnowledgeBase kb) {
		boolean pass;
		Slot nodesSlot = kb.getSlot("InvolvedNodes");
		  String KBNodes = (String) screen.getOwnSlotValue(nodesSlot);
		if ((KBNodes == null) || (itsNodes < 0)) {
			pass = true;
		} else if (KBNodes.equals("1-3")) {
			pass = (itsNodes >= 1) && (itsNodes <= 3);
		} else if (KBNodes.equals("1orMore")) {
			pass = itsNodes >= 1;
		} else if (KBNodes.equals("1-9")) {
			pass = (itsNodes >= 1) && (itsNodes <= 9);
		} else if (KBNodes.equals("4-9")) {
			pass = (itsNodes >= 4) && (itsNodes <= 9);
		} else if (KBNodes.equals("10orMore")) {
			pass = (itsNodes >= 9);
		} else {
			System.out.println("Unexpected number of nodes value: "
					+ KBNodes);
			pass = false;
		}
		return pass;
	}

} // End of class patient