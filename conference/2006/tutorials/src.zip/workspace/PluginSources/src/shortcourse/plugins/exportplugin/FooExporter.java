package shortcourse.plugins.exportplugin;

import java.io.File;
import java.io.PrintWriter;
import java.util.Iterator;

import javax.swing.JFileChooser;

import edu.stanford.smi.protege.Application;
import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.plugin.ExportPlugin;
import edu.stanford.smi.protege.util.ComponentFactory;
import edu.stanford.smi.protege.util.FileUtilities;

public class FooExporter implements ExportPlugin {
    private static final String EXTENSION = ".foo";

    public String getName() {
        return "FooFile";
    }

    public void handleExportRequest(Project project) {
        File file = promptForFooFile(project);
        if (file != null) {
            saveToFile(project, file);
        }
    }

    public void dispose() {
        // do nothing
    }
    
    public static void main(String[] args) {
        Application.main(args);
    }
    
    private File promptForFooFile(Project project) {
        String name = project.getName();
        String proposedName = new File(name + EXTENSION).getPath();
        JFileChooser chooser = ComponentFactory.createFileChooser(proposedName, EXTENSION);
        File file = null;
        if (chooser.showSaveDialog(null) == JFileChooser.APPROVE_OPTION) {
            file = chooser.getSelectedFile();
        }
        return file;
     }
    
    private void saveToFile(Project project, File file) {
        PrintWriter writer = FileUtilities.createPrintWriter(file, false);
        saveProject(project, writer);
        writer.close();
    }
    
    // Write out each class, one per line.
    private void saveProject(Project project, PrintWriter writer) {
        Iterator i = project.getKnowledgeBase().getClses().iterator();
        while (i.hasNext()) {
            Cls cls = (Cls) i.next();
            if (!cls.isIncluded()) {
                writer.println(cls.getName());
        	}
        }
    }
}
