package shortcourse.plugins.projectplugin;

import javax.swing.JMenu;
import javax.swing.JMenuItem;

import edu.stanford.smi.protege.Application;
import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.plugin.AbstractProjectPlugin;
import edu.stanford.smi.protege.ui.ProjectMenuBar;
import edu.stanford.smi.protege.ui.ProjectToolBar;
import edu.stanford.smi.protege.ui.ProjectView;

public class MenuItemInserter extends AbstractProjectPlugin {

    public void afterCreate(Project p) {
        // do nothing
    }

    public void afterLoad(Project p) {
        // do nothing
    }

    public void afterShow(ProjectView view, ProjectToolBar toolBar, ProjectMenuBar menuBar) {
        JMenu editMenu = menuBar.getMenu(1);
        if (editMenu.getText().equals("Edit")) {
            editMenu.add(new JMenuItem("My New Edit Menu Item"));
        }
    }

    public void beforeSave(Project p) {
        // do nothing
    }

    public void beforeHide(ProjectView view, ProjectToolBar toolBar, ProjectMenuBar menuBar) {
        // do nothing
    }

    public void beforeClose(Project p) {
        // do nothing
    }

    public String getName() {
        return "Menu Item Inserter";
    }

    public void dispose() {
        // do nothing
    }
    
    public static void main(String[] args) {
        Application.main(args);
    }

	public void afterSave(Project p) {
		return;
	}

}
