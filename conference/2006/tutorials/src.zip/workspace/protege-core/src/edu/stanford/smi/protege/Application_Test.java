package edu.stanford.smi.protege;

import edu.stanford.smi.protege.test.*;

/**
 * Test case for Application class
 *
 * @author    Ray Fergerson <fergerson@smi.stanford.edu>
 */
public class Application_Test extends APITestCase {
    public void testNull() {
    }

}
