
// Created on Thu Jul 20 15:33:57 PDT 2006
// "Copyright Stanford University 2002"

package newspaper;

import java.util.*;
import java.beans.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;


/** 
 */
public class Standard_Ad extends Advertisement {

	public Standard_Ad(KnowledgeBase kb, FrameID id ) {
		super(kb, id);
	}

	public Standard_Ad(KnowledgeBase kb, String name , Cls cls ) {
		super(kb, name, cls);
	}

	public void setImage(String image) {
		String oldValue =  getImage();
		ModelUtilities.setOwnSlotValue(this, "image", image);
		pcs.firePropertyChange("image", oldValue, image);
	}
	public String getImage() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "image"));
	}
/* writing listener */

	private PropertyChangeSupport pcs = new PropertyChangeSupport(this); 

	public void addPropertyChangeListener(PropertyChangeListener pcl) {
		pcs.addPropertyChangeListener(pcl);
	}
	public void removePropertyChangeListener(PropertyChangeListener pcl) {
		pcs.removePropertyChangeListener(pcl); 
	} 
// __Code above is automatically generated. Do not change
}
