
// Created on Tue Jul 18 15:37:55 PDT 2006
// "Copyright Stanford University 2002"

package newspaper;

import java.util.*;
import java.beans.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;


/** 
 */
public class Person extends DefaultSimpleInstance {

	public Person(KnowledgeBase kb, FrameID id ) {
		super(kb, id);
	}

	public Person(KnowledgeBase kb, String name , Cls cls ) {
		super(kb, name, cls);
	}

	public void setName(String name) {
		String oldValue =  getName();
		ModelUtilities.setOwnSlotValue(this, "name", name);
		pcs.firePropertyChange("name", oldValue, name);
	}
	public String getName() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "name"));
	}

	public void setOther_information(String other_information) {
		String oldValue =  getOther_information();
		ModelUtilities.setOwnSlotValue(this, "other_information", other_information);
		pcs.firePropertyChange("other_information", oldValue, other_information);
	}
	public String getOther_information() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "other_information"));
	}

	public void setPhone_number(String phone_number) {
		String oldValue =  getPhone_number();
		ModelUtilities.setOwnSlotValue(this, "phone_number", phone_number);
		pcs.firePropertyChange("phone_number", oldValue, phone_number);
	}
	public String getPhone_number() {
		return ((String) ModelUtilities.getOwnSlotValue(this, "phone_number"));
	}
/* writing listener */

	private PropertyChangeSupport pcs = new PropertyChangeSupport(this); 

	public void addPropertyChangeListener(PropertyChangeListener pcl) {
		pcs.addPropertyChangeListener(pcl);
	}
	public void removePropertyChangeListener(PropertyChangeListener pcl) {
		pcs.removePropertyChangeListener(pcl); 
	} 
// __Code above is automatically generated. Do not change
}
