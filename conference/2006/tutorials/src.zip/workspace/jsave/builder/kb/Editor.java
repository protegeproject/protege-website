
// Created on Tue Jul 18 15:37:55 PDT 2006
// "Copyright Stanford University 2002"

package newspaper;

import java.util.*;
import java.beans.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;


/** 
 *  Editors are responsible for the content of sections.
 */
public class Editor extends Error {

	public Editor(KnowledgeBase kb, FrameID id ) {
		super(kb, id);
	}

	public Editor(KnowledgeBase kb, String name , Cls cls ) {
		super(kb, name, cls);
	}

	public void setSections(Instance[] sections) {
		Instance[] oldValue =  getSections();
		Collection sectionsCollection = Arrays.asList(sections); 
		ModelUtilities.setOwnSlotValues(this, "sections", sectionsCollection);
		pcs.firePropertyChange("sections", oldValue, sections);
	}
	public Instance[] getSections(){
		return (Instance[])  ModelUtilities.getOwnSlotValues(this, "sections").toArray(new Instance[0]);
	}

	public void setResponsible_for(Instance[] responsible_for) {
		Instance[] oldValue =  getResponsible_for();
		Collection responsible_forCollection = Arrays.asList(responsible_for); 
		ModelUtilities.setOwnSlotValues(this, "responsible_for", responsible_forCollection);
		pcs.firePropertyChange("responsible_for", oldValue, responsible_for);
	}
	public Instance[] getResponsible_for(){
		return (Instance[])  ModelUtilities.getOwnSlotValues(this, "responsible_for").toArray(new Instance[0]);
	}
/* writing listener */

	private PropertyChangeSupport pcs = new PropertyChangeSupport(this); 

	public void addPropertyChangeListener(PropertyChangeListener pcl) {
		pcs.addPropertyChangeListener(pcl);
	}
	public void removePropertyChangeListener(PropertyChangeListener pcl) {
		pcs.removePropertyChangeListener(pcl); 
	} 
// __Code above is automatically generated. Do not change
}
