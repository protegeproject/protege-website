
// Created on Tue Jul 18 15:37:55 PDT 2006
// "Copyright Stanford University 2002"

package newspaper;

import java.util.*;
import java.beans.*;
import edu.stanford.smi.protege.model.*;
import edu.stanford.smi.protege.util.*;


/** 
 *  A salesperson sells, and is reponsible for the content of, advertisements.
 */
public class Salesperson extends Employee {

	public Salesperson(KnowledgeBase kb, FrameID id ) {
		super(kb, id);
	}

	public Salesperson(KnowledgeBase kb, String name , Cls cls ) {
		super(kb, name, cls);
	}
/* writing listener */

	private PropertyChangeSupport pcs = new PropertyChangeSupport(this); 

	public void addPropertyChangeListener(PropertyChangeListener pcl) {
		pcs.addPropertyChangeListener(pcl);
	}
	public void removePropertyChangeListener(PropertyChangeListener pcl) {
		pcs.removePropertyChangeListener(pcl); 
	} 
// __Code above is automatically generated. Do not change
}
