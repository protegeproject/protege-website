package shortcourse.plugins.tabwidget;

import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Collection;

import javax.swing.JButton;
import javax.swing.JTextField;
import javax.swing.SwingConstants;

import edu.stanford.smi.protege.model.Project;
import edu.stanford.smi.protege.resource.Icons;
import edu.stanford.smi.protege.widget.AbstractTabWidget;

// an example tab
public class FrameCounter extends AbstractTabWidget {
    /**
	 * 
	 */
	private static final long serialVersionUID = 4598424440166134279L;
	private static final int MAX_FRAMES = 500;
    private JTextField field;
    private JButton button;

    public void initialize() {
        initializeTabLabel();
        button = createButton();
        field = createOutputTextField();
        layoutUI();
    }

    private void layoutUI() {
	    setLayout(new FlowLayout());
	    add(button);
	    add(field);
    }
    
    private void initializeTabLabel() {
        setLabel("Frame Counter");
        setIcon(Icons.getInstanceIcon());
    }

    private JButton createButton() {
        JButton button = new JButton("Update Frame Counter");
        button.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent event) {
                updateTextField();
            }
        });
        return button;
    }

    private JTextField createOutputTextField() {
	    JTextField field = new JTextField(10);
	    field.setEnabled(false);
	    field.setHorizontalAlignment(SwingConstants.RIGHT);
	    return field;
    }
    
    private void updateTextField() {
	    int count = getKnowledgeBase().getFrameCount();
	    field.setText(String.valueOf(count));
    }
    
    @SuppressWarnings("unchecked")
	public static boolean isSuitable(Project project, Collection errors) {
        boolean isSuitable;
        if (project.getKnowledgeBase().getFrameCount() > MAX_FRAMES) {
            isSuitable = false;
            String text = "Project too big, max=" + MAX_FRAMES + " frames";
            errors.add(text);
        } else {
            isSuitable = true;
        }
        return isSuitable;
    }

    // this method is useful for debugging
    public static void main(String[] args) {
        edu.stanford.smi.protege.Application.main(args);
    }
}
