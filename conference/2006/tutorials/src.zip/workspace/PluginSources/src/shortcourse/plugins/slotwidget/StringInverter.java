package shortcourse.plugins.slotwidget;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.util.Collection;

import javax.swing.AbstractAction;
import javax.swing.Icon;
import javax.swing.JTextField;
import javax.swing.event.DocumentEvent;
import javax.swing.event.DocumentListener;

import edu.stanford.smi.protege.model.Cls;
import edu.stanford.smi.protege.model.Facet;
import edu.stanford.smi.protege.model.Slot;
import edu.stanford.smi.protege.model.ValueType;
import edu.stanford.smi.protege.util.CollectionUtilities;
import edu.stanford.smi.protege.util.ComponentFactory;
import edu.stanford.smi.protege.util.ComponentUtilities;
import edu.stanford.smi.protege.util.LabeledComponent;
import edu.stanford.smi.protege.widget.AbstractSlotWidget;

public class StringInverter extends AbstractSlotWidget {
    /**
	 * 
	 */
	private static final long serialVersionUID = -4549417799400998848L;
	private JTextField field;
    private AbstractAction invertAction;

    // set up the widget
	public void initialize() {
        field = ComponentFactory.createTextField();
        field.setBackground(Color.pink);
        field.getDocument().addDocumentListener(createDocumentListener());

        invertAction = new AbstractAction("Invert String", getInvertIcon()) {

			private static final long serialVersionUID = 1L;

			public void actionPerformed(ActionEvent event) {
                StringBuffer buf = new StringBuffer(field.getText());
                buf.reverse();
                field.setText(buf.toString());
            }
        };
        LabeledComponent c = new LabeledComponent(getLabel(), field);
        c.addHeaderButton(invertAction);
        add(c);

// set the default size to be the same as the standard 
// "TextFieldWidget".
        setPreferredColumns(2);
        setPreferredRows(1);
    }

    // return the current value displayed by the widget
    public Collection getValues() {
        String s = field.getText();
        return CollectionUtilities.createCollection(s);
    }

    // initialize the display value
    public void setValues(Collection c) {
        String s = (String) CollectionUtilities.getFirstItem(c);
        field.setText(s);
    }

    // change whether or not the user can modify the displayed value
    public void setEditable(boolean editable) {
        field.setEnabled(editable);
        invertAction.setEnabled(editable);
    }

/* indicate whether an instance of this class can handle the 
 * Class-Slot binding.
     * Note that "facet" is historical and is always null. This 
     * widget handles
     * cardinality-single string slots.
     */
    public static boolean isSuitable(Cls cls, Slot slot, Facet facet) {
        boolean isString = cls.getTemplateSlotValueType(slot) == 
ValueType.STRING;
        boolean isCardinalitySingle 
		= !cls.getTemplateSlotAllowsMultipleValues(slot);
        return isString && isCardinalitySingle;
    }

/* Access our icon in a way that works for both standalone class 
 * files and gif's in a
     * directory and with all files in a jar.  The image is in the same 
     * directory
     * as the specified class file.
     */
    private static Icon getInvertIcon() {
        return ComponentUtilities.loadImageIcon(StringInverter.class,
 "invert.gif");
    }

// This listener updates the kb as characters are typed. This is 
// not the usual Protege convention.
    private DocumentListener createDocumentListener() {
        return new DocumentListener() {
            public void changedUpdate(DocumentEvent event) {
                // notify the system that the value has changed
                valueChanged();
            }
            public void removeUpdate(DocumentEvent event) {
                valueChanged();
            }
            public void insertUpdate(DocumentEvent event) {
                valueChanged();
            }
        };
    }

    // method to allow easy debuging
    public static void main(String[] args) {
        edu.stanford.smi.protege.Application.main(args);
    }
}
