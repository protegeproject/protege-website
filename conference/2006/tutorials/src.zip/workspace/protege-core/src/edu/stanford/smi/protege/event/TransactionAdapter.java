package edu.stanford.smi.protege.event;

public class TransactionAdapter implements TransactionListener {

    public void transactionBegin(TransactionEvent event) {
    }

    public void transactionEnded(TransactionEvent event) {
    }

}
