#!/bin/sh

PROTEGE_HOME="/Users/tredmond/dev/Protege_3.2_beta"
JSAVE_HOME=/Users/tredmond/admin/Classes/workspace/jsave/builder

CLASSPATH=${JSAVE_HOME}/jsave.jar:${PROTEGE_HOME}/protege.jar

java  -Dprotege.dir=${PROTEGE_HOME} -cp ${CLASSPATH} \
    edu.stanford.smi.protegex.jsave.protege2java ${JSAVE_HOME}/newspaper.cfg
